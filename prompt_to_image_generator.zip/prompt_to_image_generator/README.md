
# Prompt to Image Generator

AI-based image generation project using Gradio and Stable Diffusion.

## Features
- Text-to-image generation
- AI advertisement creation
- Easy deployment on Hugging Face

## Run

pip install -r requirements.txt

python app.py
