
import gradio as gr

def generate(prompt):
    return f"Generated image for: {prompt}"

iface = gr.Interface(
    fn=generate,
    inputs="text",
    outputs="text",
    title="Prompt to Image Generator"
)

iface.launch()
